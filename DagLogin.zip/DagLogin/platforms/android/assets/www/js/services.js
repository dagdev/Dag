angular.module('app.services', ['ionic','ngCordova'])

.factory('BlankFactory', [function(){

}])

.service('BlankService', [function(){

}]);

