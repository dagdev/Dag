angular.module('app.directives', [])

.directive('blank', [function(){
}]);
