angular.module('app.controllers', ['ngOpenFB'])
  
.controller('loginCtrl', function($scope, $state, ngFB) {

	$scope.fbLogin = function () {
	    ngFB.login({scope: 'email,publish_actions, user_friends, public_profile'}).then(
	        function (response) {
	            if (response.status === 'connected') {
	                console.log('Facebook login succeeded');
	                $scope.closeLogin();
	            } else {
	                alert('Facebook login failed');
	            }
	        });
	};

	$scope.closeLogin = function () {
		$state.go('dag');
	}

 })

//Dag Controller

.controller('dagCtrl', function($scope, $ionicPopup, $ionicModal, $cordovaGeolocation ) {

	var options = {timeout: 10000, enableHighAccuracy: true};

	$cordovaGeolocation.getCurrentPosition(options).then(function(position){

		var latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);
		$scope.posicao = latLng;
		$scope.map     = iniciaMapa(position);

		//Espera o Mapa carregar para adionar o indicador do usuario.
		google.maps.event.addListenerOnce($scope.map, 'idle', function(){

			var marker = new google.maps.Marker({
			    map: $scope.map,
			    animation: google.maps.Animation.DROP,
			    position: latLng
			 });      
		   	
		   	google.maps.event.addListener(marker, 'click', function () {
		      $scope.novaBolhaModal();
		  	});

		  	$scope.map.addListener('click', function(event){
		  		escondeMenuBotoes();
		  	})

		});


	}, function(error){
		console.log("Could not get location");
	});

    $scope.centralizaMapa = function(){
    	$scope.map.setCenter($scope.posicao);
    }

	$ionicModal.fromTemplateUrl('templates/configuracoes.html', {
	    
	    id: '1',
	    scope: $scope,
	    backdropClickToClose: true,
	    animation: 'slide-in-up'

	  }).then(function(modal) {
	    $scope.configuracoes = modal;
	  });

	$ionicModal.fromTemplateUrl('templates/novaBolha.html', {
	    
	    id: '2',
	    controller: 'novaBolhaCtrl',
	    scope: $scope,
	    backdropClickToClose: true,
	    animation: 'slide-in-up'

	  }).then(function(modal) {
	    $scope.novaBolha = modal;
	  });

	$ionicModal.fromTemplateUrl('templates/listaCategorias.html', {
	    
	    id: '3',
	    scope: $scope,
	    backdropClickToClose: true,
	    animation: 'slide-in-up'

	  }).then(function(modal) {
	    $scope.listaCategorias = modal;
	  });

	$ionicModal.fromTemplateUrl('templates/chat.html', {
	    
	    id: '3',
	    scope: $scope,
	    backdropClickToClose: true,
	    animation: 'slide-in-up'

	  }).then(function(modal) {
	    $scope.chat = modal;
	  });

	$scope.configuracoesModal = function(){
		$scope.configuracoes.show();
	};

	$scope.novaBolhaModal = function(){
		$scope.novaBolha.show();
	};

	$scope.listaCategoriasModal = function(){
		$scope.listaCategorias.show();
	};

	$scope.chatModal = function(){
		$scope.chat.show();
	};

	$scope.fechaConfiguracoesModal = function(){
		$scope.configuracoes.hide();
	};

	$scope.fechaListaCategoriasModal = function(){
		$scope.listaCategorias.hide();
	};

	$scope.fechaChatModal = function(){
		$scope.chat.hide();
	};
})

   
.controller('chatCtrl', function($scope) {

})
   
.controller('dagUpCtrl', function($scope) {

})
      
.controller('signupCtrl', function($scope) {

})
   
.controller('configuracoesCtrl', function($scope) {

})

.controller('novaBolhaCtrl', function($scope, $ionicModal) {

})
  
.controller('Ctrl', function($scope, ngFB) {

})