var menu;

function clickBotao (button) {
	menu = document.getElementById("menuBotoes");
	
	if ( menuVisivel()){

		escondeMenuBotoes();

	}else{

		mostraMenuBotoes();
	}

}

function menuVisivel(){
	var menuVisivel = false;

	if ( menu.style.visibility == "visible" ){
		menuVisivel = true;
	}

	return menuVisivel;
}

function mostraMenuBotoes(){
	menu.style.visibility = "visible";
}

function escondeMenuBotoes(){

	menu.style.visibility = "hidden";

}

